# LUMEN V7 — Direct Install

## Can you install directly? YES.

This is a standard Android APK sideload:

1. **APK file**: Build produces `app/build/outputs/apk/debug/app-debug.apk` and `release/app-release.apk`
2. **Direct install**: Copy APK to phone, tap it, enable "Install unknown apps" when prompted — installs like any app, no Play Store needed
3. **PS4 controller**: Pair DS4 via Bluetooth Settings > Pair new device > hold Share+PS > LUMEN sees it as input
4. **Storage**: All creations stored locally at `/data/data/com.lumen.app/files/creations/` + `/DCIM/LUMEN/` for screenshots/recordings — no internet needed

## What we deliver here:
- `app/src/main/res/drawable/` — 30 icons transparent (22 original + 8 new: export, screen_record, controller_settings, hint_toggle, ui_customization, search_local, time_date, menu_wire_anchor)
- `app/src/main/java/com/lumen/logic/gadgets/` — all Dreams gadgets FULL MODES + V4 creation types + V5 offline export + V6 stripped + V6c controller/hints/UI
- AndroidManifest with RECORD_AUDIO, STORAGE, BLUETOOTH permissions for PS4 controller + screen record

## To build installable APK:
```
cd LUMEN_APK
./gradlew assembleDebug  -> produces app-debug.apk you can install directly
./gradlew assembleRelease -> signed release apk
```

Or open in Android Studio: File > Open > LUMEN_APK folder > Run.

## Features in this APK (100% offline, no online):
- Scene Editor same as Dreams: Assembly/Sculpt/Paint/Animation/Sound/Test
- Search own creations to stamp (lamp, puppet, etc)
- Save as Element/Scene/Dream/Collection + subtypes Sculpture/Gameplay/Audio/Character/Showcase
- Local storage only, no DreamSurfing/Mm Picks/Trending/Autosurf/tags/thumbs/comment/follow/collab/Prize Bubbles/homespaces/Dream Queen/Home Sweet Home trophy/COLLABORATION/trophy system
- Export: APK/EXE/HTML/JAVA + MP3/MIDI/WAV + OBJ/FBX/GLTF/GLB/STL/BLEND/DAE/PLY
- Screen record via Share: single=screenshot, double=record, long=save clip
- Controller options: schemes, sensitivity, invert, vibration, wisp speed/size, full PS4 mapping
- Hint toggle + UI customization (theme, menu scale/opacity, grid, thermo, wire colors, etc)
- Local remixing COPY_EDIT/REFERENCE with genealogy

You CAN install directly once built. We provide source ready to build in Android Studio, 30 icons wired.
