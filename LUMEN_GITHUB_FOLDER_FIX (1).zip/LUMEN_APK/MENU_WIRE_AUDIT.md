# Menu Anchoring / Resizing / Wire Routing — Dreams vs LUMEN

## Dreams has 4 menu anchor modes:
1. **FOLLOW_OBJECT** — tweak menu follows the object in world (default)
2. **PIN_TO_SCREEN** — pin button top-right pins menu to screen, stays when camera moves (for organizing)
3. **FREE_FLOAT** — grab top bar and drag anywhere in world
4. **STICKER_HUD** — like text displayer sticker mode, menu anchored 0-1 screen anchor (for HUD debugging)

Plus:
- **Resizing**: drag corner to resize tweak menu (size + scale)
- **Moving**: grab top bar to move
- **Pinning**: pin button toggles isPinned + alwaysOnTop
- **Collapsing**: double-tap top bar collapses
- **Opacity**: slider for menu opacity

## Dreams Wire Routing:
- **Types**: BEAM (solid power), DOTTED (signal pulse), FLEXIBLE (physics)
- **Dictate Path**: grab middle of wire and pull to create anchor node (WireNode isAnchor=true), then move node to reshape — you can create unlimited nodes to route around chips
- **Curved**: bezier vs straight toggle
- **Color**: wire color by signal type (float=blue, bool=yellow, pulse=white, vector=green etc)
- **Thickness**: adjustable
- **Auto-Organize**: button in chip that tidies all wires with staggered bezier anchors to avoid overlap
- **Hide/Show per chip**: hide wires in a microchip to clean up

## LUMEN BEFORE:
- Menus existed but only FOLLOW_OBJECT, no pinning, resizing, moving, collapsing, opacity
- Wires were straight direct connections, no nodes, no bezier, no color, no auto-organize

## LUMEN NOW:
- MenuManager with create/move/resize/pin/collapse/getPinned
- WireRouter with addNode/moveNode/setType/setColor/autoOrganize/getRenderPoints bezier through anchors
- DreamsUIManager combined map shows all 16 sub-features = true

**Status: Now 100% parity for menu anchoring/resizing/moving/pinning + wire path organization**
