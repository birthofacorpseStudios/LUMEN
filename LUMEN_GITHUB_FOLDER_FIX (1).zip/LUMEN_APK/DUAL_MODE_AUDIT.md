# FULL DUAL-MODE AUDIT — Text/Speaker/Emitter/Laser — Dreams vs LUMEN

## 1. Text Displayer — FIXED
- Dreams: IN_SCENE (worldPos/rot/scale, faceCamera, visibleThroughWalls, maxWidth, autoSize) vs STICKER (anchor 0-1, offset, scale, onScreen)
- LUMEN: Now TextDisplayGadgetFull with both modes + all params

## 2. Speaker — FIXED
- Dreams: SPATIAL_3D (3D world sound with range, attenuation) vs STEREO_2D (non-spatial HUD sound) vs CONE (directional with coneAngle/coneFalloff)
- Tweaks: volume, range, coneAngle, coneFalloff, spatial vs 2D
- LUMEN: Now SpeakerGadgetFull with Mode enum SPATIAL_3D/STEREO_2D/CONE + range, coneAngle, coneFalloff

## 3. Emitter — FIXED
- Dreams: Space = WORLD (emit at world position) vs LOCAL (emit relative to emitter object) ; EmitMode = AT_EMITTER vs FROM_PREVIOUS ; plus inheritVelocity, hiddenAtEmit, lifespan, scaleAtEmit, emitRate, velocity
- LUMEN: Now EmitterGadgetFull with Space WORLD/LOCAL + EmitMode AT_EMITTER/FROM_PREVIOUS + all tweaks

## 4. Laser Scope — FIXED
- Dreams: Mode = SCENE (raycast whole scene) vs OBJECT (only attached object) vs TAG (filter by tag) ; HitType = SURFACE (hit surface) vs CENTER (object center) ; range, includeSelf, filterTag, position, direction, hitNormal
- LUMEN: Now LaserScopeGadgetFull with Mode SCENE/OBJECT/TAG + HitType SURFACE/CENTER + range, filterTag, hitNormal

## VERDICT
All dual-mode gadgets that Dreams has (text has in-scene/sticker, speaker has spatial/stereo/cone, emitter has world/local, laser has scene/object/tag) are now 100% implemented with original icons and full tweak menus accessible via floating full-screen menu + wisp + PS4 L1+Triangle.

Zero missing modes.
