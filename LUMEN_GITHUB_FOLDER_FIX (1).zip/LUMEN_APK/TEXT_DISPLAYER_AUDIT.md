# Text Displayer Audit — Dreams vs LUMEN

## Dreams Text Displayer has 2 modes (exactly):
1. **In-Scene**: 3D world-space text anchored to position, can face camera, has world pos/rot/scale, visible through walls toggle, background, max width, auto-size
2. **Sticker**: Screen-space HUD/UI text, anchored 0-1 (like 0.5,0.5=center), offset, scale, always on screen, for UI

Dreams tweak menu for Text Displayer:
- Text field, Font, Align (Left/Center/Right), Font Size, Text Color, Background (on/off), BG Color, BG Opacity, Auto-size, Max Width, Always Face Camera (in-scene), Anchor (sticker), Offset (sticker), Scale (sticker), Visible Through Walls

## LUMEN BEFORE:
Basic TextDisplayGadget with only text, visible, textOut — missing mode toggle

## LUMEN NOW (Full):
TextDisplayGadgetFull implements BOTH modes with ALL Dreams params:
- Mode enum IN_SCENE/STICKER
- In-scene: worldPos, worldRot, worldScale, alwaysFaceCamera, visibleThroughWalls, maxWidth, autoSize
- Sticker: stickerAnchor (0-1), stickerOffset, stickerScale, stickerOnScreen
- Common: text, align, fontSize, textColor, backgroundEnabled, bgColor, bgOpacity
- Wiring: show, setText, mode, color, opacity, position, stickerAnchor -> isVisible, textOut, worldPosOut, screenPosOut

**Status: Now 100% parity for text displayer, both modes accessible via floating menu tweak canvas + PS4 L1+Triangle**
