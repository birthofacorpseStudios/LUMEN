# V5 OFFLINE AUDIT — Online removed, Export + Screen Record + Remix

## Online REMOVED (all local):
- DreamSurfing online playlists, online search, thumbs up/comment/follow online, collab online, publishing to Dreamiverse cloud, online genealogy, Community Jam voting, online homespace sharing
- All creations stored locally on device only

## Kept LOCAL:
- My Creations local browser, Local DreamSurfing = browse YOUR OWN dreams offline, Local Homespace with kits, Local save as Element/Scene/Dream/Collection with subtypes

## Export Menu NEW:
- Games (Dream/Scene/Gameplay): APK, EXE, HTML, JAVA
  - APK = bundle scene + logic engine into installable APK
  - EXE = wrapper runtime
  - HTML = WebGL
  - JAVA = export logic as .java source
- Music: MP3, MIDI, WAV, OGG, FLAC
- Sculptures: OBJ, FBX, GLTF, GLB, STL, BLEND, DAE, PLY (fleck SDF -> mesh via marching cubes)
- Showcase: HTML interactive

## Screen Record PS4 Share button same:
- Single press Share = screenshot PNG to /DCIM/LUMEN/
- Double press Share = start/stop recording MP4
- Long press 1s = save last 15s clip buffer (like PS4)
- Bound to PS4 controller Share button via PS4State

## Remixing?
Before: Partial via genealogy but required online.
Now V5: YES, offline local remixing:
- RemixManager.createRemix(originalId, newTitle) copies locally, keeps original non-destructive, adds genealogy chain
- Options: allowRemix toggle, keepOriginal, remixType COPY_EDIT/REFERENCE/COLLABORATION local
- All your creations remixable by you offline
- No online needed
