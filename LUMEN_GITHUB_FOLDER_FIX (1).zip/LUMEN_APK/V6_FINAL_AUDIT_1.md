# V6 FINAL STRIPPED — per user request

## REMOVED (all online/social/trophy/homespace features):
- DreamSurfing Mm Picks
- DreamSurfing Trending
- Autosurf
- tags search online
- thumbs up
- comment
- follow creator
- follow creation / follow creation
- collab / collaboration suggest
- Prize Bubbles
- homespaces (personal hub)
- Dream Queen's homespace tutorial
- Home Sweet Home trophy (spend 30min decorating) — trophy list
- allowRemix toggle
- COLLABORATION remixType

## KEPT — PURE CREATION MODE ONLY:
- My Creations local only
- Scene Editor works same as Dreams Edit Mode
- Search YOUR OWN creations for elements to stamp into scene — YES
- Search puppets (your own puppet templates) to stamp — YES
- Assembly, Sculpt, Paint, Animation, Sound, Test modes
- Save as Element/Scene/Dream/Collection with subtypes Sculpture/Gameplay/Audio/Character/Showcase
- Local offline storage only (/data/data/com.lumen.app/files/creations/)
- Export to APK/EXE/HTML/JAVA/MP3/MIDI/WAV/OBJ/FBX/GLTF/GLB/STL etc
- Screen record via Share button (single=screenshot, double=record, long=save clip)
- Local remixing COPY_EDIT / REFERENCE only (no COLLABORATION), no allowRemix toggle — all your creations remixable by you, non-destructive, genealogy local

## Creation Mode Search — YES we have it:
- CreationSearchManager.searchOwnCreations(query, filterType) — search your local library
- Example: type "lamp" -> finds your lamp sculpture, select, stamp into Scene at position
- Example: type "puppet" -> searchPuppets() finds Basic/Deluxe puppets you created, stamp into scene
- Like Dreams Assembly Mode search but offline: search Dreamiverse -> now search YOUR OWN creations
- After stamp: you can scope into object and repaint, retweak, resculpt (same as Dreams)

## Scene Editor — YES works same:
- SceneEditorManager with EditMode ASSEMBLY/SCULPT/PAINT/ANIMATION/SOUND/TEST
- Assembly: search own creations, stamp elements, place gadgets, wire, microchips, group/ungroup
- Sculpt: sphere/cube/cylinder/lozenge, looseness, wax, metallic, glow, fleck type/density, opacity, cutout, soft blend, impasto, bevel, smear, stamp, spray, clone, grid, mirror, guides
- Paint: fleck/splat/coat/gradient, 15 fleck shapes, mirror, kaleidoscope
- Animation: timeline, keyframes, labels, playhead, looping, ping-pong, onion skin, blend, action recorder, performance recorder
- Sound: 16 pads, infinite disk-streamed recording (beyond Dreams 3-min cap), piano roll, step sequencer, drum kits, FX rack
- Test: play with live gadget debug, see gadgets windows live, thermo display
- Controls same: L1+R2 clone, R1 hold camera relative, L1+Circle exit editor, scope into object

**Verdict: V6 is pure offline creation app, no social/homespace/trophy/collab, but full creation search and scene editor identical to Dreams, plus export and Share recording.**
Trophy system removed
