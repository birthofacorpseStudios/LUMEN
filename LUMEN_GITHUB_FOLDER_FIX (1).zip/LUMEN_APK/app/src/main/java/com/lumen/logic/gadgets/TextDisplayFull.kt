package com.lumen.logic.gadgets
import com.lumen.logic.core.*

class TextDisplayGadgetFull(id: String): LogicGadget(id, "Text Display", "ic_text_display") {
    enum class Mode { IN_SCENE, STICKER } // Dreams has exactly these 2
    enum class Align { LEFT, CENTER, RIGHT }
    
    // CORE TEXT (Dreams text displayer params)
    var text: String = "Hello LUMEN"
    var mode: Mode = Mode.IN_SCENE
    var visible: Boolean = true
    var align: Align = Align.CENTER
    var fontSize: Float = 1f
    var textColor: Triple<Float,Float,Float> = Triple(1f,1f,1f)
    var backgroundEnabled: Boolean = false
    var bgColor: Triple<Float,Float,Float> = Triple(0f,0f,0f)
    var bgOpacity: Float = 0.7f
    var autoSize: Boolean = true
    var maxWidth: Float = 10f
    var alwaysFaceCamera: Boolean = true // in-scene only
    
    // STICKER MODE ONLY (Dreams HUD mode)
    var stickerAnchor: Pair<Float,Float> = Pair(0.5f,0.5f) // 0-1 screen anchor
    var stickerOffset: Pair<Float,Float> = Pair(0f,0f)
    var stickerScale: Float = 1f
    var stickerOnScreen: Boolean = true // always on screen vs world
    
    // IN-SCENE MODE ONLY
    var worldPos: Triple<Float,Float,Float> = Triple(0f,2f,0f)
    var worldRot: Triple<Float,Float,Float> = Triple(0f,0f,0f)
    var worldScale: Float = 1f
    var visibleThroughWalls: Boolean = false
    
    init {
        // Inputs match Dreams wiring
        input("show", SignalType.BOOL)
        input("setText", SignalType.OBJECT_REF)
        input("mode", SignalType.FLOAT) // 0=inScene, 1=sticker
        input("color", SignalType.VECTOR3)
        input("opacity", SignalType.FLOAT)
        input("position", SignalType.VECTOR3) // for in-scene
        input("stickerAnchor", SignalType.VECTOR3) // for sticker
        
        output("isVisible", SignalType.BOOL)
        output("textOut", SignalType.OBJECT_REF)
        output("worldPosOut", SignalType.VECTOR3)
        output("screenPosOut", SignalType.VECTOR3)
    }
    
    override fun onTick(d: Long, ctx: LogicContext) {
        emit("isVisible", visible, ctx)
        emit("textOut", text, ctx)
        emit("worldPosOut", worldPos, ctx)
        // Convert anchor to screen pos (0-1 to pixels) — sticker mode
        emit("screenPosOut", Triple(stickerAnchor.first + stickerOffset.first, stickerAnchor.second + stickerOffset.second, stickerScale), ctx)
    }
    
    override fun onSignal(p: String, v: Any?, ctx: LogicContext) {
        when(p) {
            "show" -> visible = v as? Boolean ?: true
            "setText" -> text = v as? String ?: text
            "mode" -> mode = if((v as? Float ?: 0f) < 0.5f) Mode.IN_SCENE else Mode.STICKER
            "color" -> textColor = v as? Triple<Float,Float,Float> ?: textColor
            "opacity" -> bgOpacity = (v as? Float ?: bgOpacity).coerceIn(0f,1f)
            "position" -> worldPos = v as? Triple<Float,Float,Float> ?: worldPos
            "stickerAnchor" -> {
                val vec = v as? Triple<Float,Float,Float>
                if(vec!=null) stickerAnchor = Pair(vec.first, vec.second)
            }
        }
    }
    
    fun toTweakMenu(): Map<String, Any> = mapOf(
        "mode" to mode.name, // IN_SCENE vs STICKER — Dreams exact toggle
        "text" to text,
        "align" to align.name,
        "fontSize" to fontSize,
        "textColor" to textColor,
        "background" to backgroundEnabled,
        "bgColor" to bgColor,
        "bgOpacity" to bgOpacity,
        "autoSize" to autoSize,
        "maxWidth" to maxWidth,
        "alwaysFaceCamera" to alwaysFaceCamera, // in-scene param
        "stickerAnchor" to stickerAnchor, // sticker param
        "stickerOffset" to stickerOffset,
        "stickerScale" to stickerScale,
        "visibleThroughWalls" to visibleThroughWalls,
        "worldPos" to worldPos,
        "worldRot" to worldRot,
        "worldScale" to worldScale
    )
}
