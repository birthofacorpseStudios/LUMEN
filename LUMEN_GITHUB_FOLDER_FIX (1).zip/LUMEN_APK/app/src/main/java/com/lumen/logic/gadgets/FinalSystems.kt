package com.lumen.logic.gadgets
import com.lumen.logic.core.*

// --- TIMELINE & ANIMATION (Dreams timeline is heart of animation) ---
class TimelineGadget(id: String): LogicGadget(id, "Timeline", "ic_timeline_label") {
    var currentTimeMs: Long = 0; var durationMs: Long = 10000; var isPlaying = false; var isLooping = false
    var labels: MutableList<Pair<Long,String>> = mutableListOf() // Dreams timeline labels
    init {
        input("play", SignalType.PULSE); input("pause", SignalType.PULSE); input("stop", SignalType.PULSE)
        input("setTime", SignalType.FLOAT); input("addLabel", SignalType.OBJECT_REF)
        output("currentTime", SignalType.FLOAT); output("isPlaying", SignalType.BOOL)
        output("onLabel", SignalType.OBJECT_REF); output("finished", SignalType.PULSE)
    }
    override fun onTick(d: Long, ctx: LogicContext) {
        if(!isPlaying) return
        currentTimeMs += d
        if(currentTimeMs >= durationMs){ if(isLooping) currentTimeMs=0 else { isPlaying=false; emit("finished", true, ctx) } }
        emit("currentTime", currentTimeMs/1000f, ctx)
        labels.filter{ it.first in (currentTimeMs-d) until currentTimeMs }.forEach{ emit("onLabel", it.second, ctx) }
    }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext) {
        when(p){ "play"-> isPlaying=true; "pause"-> isPlaying=false; "stop"->{ isPlaying=false; currentTimeMs=0 }
                "setTime"-> currentTimeMs = ((v as? Float ?:0f)*1000).toLong()
                "addLabel"-> labels.add(Pair(currentTimeMs, v as? String ?: "label")) }
    }
}

class ActionRecorderGadget(id: String): LogicGadget(id, "Action Recorder", "ic_action_recorder") {
    var isRecording = false; var recordedFrames: MutableList<Triple<Float,Float,Float>> = mutableListOf()
    init { input("record", SignalType.BOOL); input("play", SignalType.PULSE); input("target", SignalType.OBJECT_REF); output("recorded", SignalType.BOOL) }
    override fun onTick(d: Long, ctx: LogicContext) {
        if(!isRecording) return
        val obj = ctx.sceneObjects.values.firstOrNull() ?: return
        recordedFrames.add(obj.pos)
    }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        when(p){ "record"-> isRecording = v as? Boolean ?: false; "play"->{ recordedFrames.forEachIndexed{ i, pos -> /* playback logic */ }; emit("recorded", true, ctx) } }
    }
}

class BlendGadget(id: String): LogicGadget(id, "Blend", "ic_blend_animation") {
    var blendFactor: Float = 0.5f
    init { input("a", SignalType.FLOAT); input("b", SignalType.FLOAT); input("blend", SignalType.FLOAT); output("result", SignalType.FLOAT) }
    override fun onTick(d: Long, ctx: LogicContext){
        val a = inputs["a"]?.value as? Float ?:0f; val b = inputs["b"]?.value as? Float ?:0f
        val f = inputs["blend"]?.value as? Float ?: blendFactor
        emit("result", a*(1-f)+b*f, ctx)
    }
}

// --- PHYSICS (Dreams collision/gravity tweaks) ---
class GravityTweakerGadget(id: String): LogicGadget(id, "Gravity Tweaker", "ic_gravity") {
    var gravity: Triple<Float,Float,Float> = Triple(0f,-9.8f,0f)
    init { input("gravity", SignalType.VECTOR3); output("gravityOut", SignalType.VECTOR3) }
    override fun onTick(d: Long, ctx: LogicContext){ emit("gravityOut", gravity, ctx) }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){ if(p=="gravity") gravity = v as? Triple<Float,Float,Float> ?: gravity }
}

class CollisionTweakerGadget(id: String): LogicGadget(id, "Collision", "ic_collision") {
    var isMovable = true; var isGrabbable = true; var isClimbable = false; var collisionEnabled = true
    init {
        input("movable", SignalType.BOOL); input("grabbable", SignalType.BOOL)
        input("climbable", SignalType.BOOL); input("collidable", SignalType.BOOL)
        output("isGrabbed", SignalType.BOOL)
    }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        when(p){ "movable"-> isMovable = v as? Boolean ?: true; "grabbable"-> isGrabbable = v as? Boolean ?: true
                "climbable"-> isClimbable = v as? Boolean ?: false; "collidable"-> collisionEnabled = v as? Boolean ?: true }
    }
}

class ForceApplierGadget(id: String, val target: String): LogicGadget(id, "Force Applier", "ic_force") {
    init { input("force", SignalType.VECTOR3); input("apply", SignalType.PULSE) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        if(p=="apply"){ val f = inputs["force"]?.value as? Triple<Float,Float,Float> ?: Triple(0f,0f,0f); ctx.sceneObjects[target]?.let{ it.pos = Triple(it.pos.first+f.first, it.pos.second+f.second, it.pos.third+f.third) } }
    }
}

// --- PUBLISHING & COMMUNITY (Dreams Surf/Jam) ---
class PublishingGadget(id: String): LogicGadget(id, "Publishing", "ic_publishing") {
    var title=""; var tags= mutableListOf<String>(); var remixable=true; var credits= mutableListOf<String>()
    init { input("publish", SignalType.PULSE); output("published", SignalType.PULSE); output("dreamId", SignalType.OBJECT_REF) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){ if(p=="publish"){ val dreamId="dream_${System.currentTimeMillis()}"; ctx.variables["lastPublished"]=dreamId; emit("published", true, ctx); emit("dreamId", dreamId, ctx) } }
}

class ScoreSensorGadget(id: String): LogicGadget(id, "Score Sensor", "ic_score_sensor") {
    var threshold=100
    init { input("score", SignalType.FLOAT); output("scorePassed", SignalType.PULSE); output("currentScore", SignalType.FLOAT) }
    override fun onTick(d: Long, ctx: LogicContext){}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){ val s=(v as? Float ?:0f).toInt(); emit("currentScore", s.toFloat(), ctx); if(s>=threshold) emit("scorePassed", true, ctx) }
}

// --- TWEAK MENUS DEFINITION (Every Dreams tweak menu) ---
object DreamsTweakMenus {
    // Every object in Dreams has L1+Triangle tweak menu - this defines ALL parameters
    val sculptTweak = listOf("looseness","wax","metallic","glow","fleckType","fleckDensity","opacity","blend","cutout","softBlend","impasto","bevel")
    val paintTweak = listOf("looseness","wax","glow","metallic","opacity","fleckDensity","colorMode","tint","coating")
    val objectTweak = listOf("movable","grabbable","climbable","collidable","scannable","visible","mass","friction","bounciness","damping")
    val lightTweak = listOf("color","brightness","range","spotAngle","shadows","fogAffects","sunAndSky","vignette","bloom","aperture")
    val cameraTweak = listOf("fov","aperture","focusDistance","shakeStrength","lensDistortion","followDistance","rigDampening")
    val moverTweak = listOf("speed","acceleration","deceleration","damping","target","localSpace","boltAtEnd")
    val emitterTweak = listOf("emitRate","maxEmitted","lifespan","scaleAtEmit","velocity","inheritVelocity","hiddenAtEmit")
    val logicTweak = listOf("powered","visible","wired","microchipCollapsed")
    val musicTweak = listOf("bpm","timeSignature","key","loop","volume","reverb","delay","eq","compressor","chorus","instrumentType","slice","adsr")
    val puppetTweak = listOf("walkSpeed","runSpeed","jumpHeight","doubleJump","canClimb","canGrab","possessionRadius","health","stamina")
    val timelineTweak = listOf("playbackSpeed","loop","pingPong","labels","keyframes","onionSkin","blend","record")
    val thermoTweak = listOf("gameplayThermo","graphicsThermo","audioThermo","logicThermo")
}
