package com.lumen.creation

enum class CreationType { ELEMENT, SCENE, DREAM, COLLECTION }
enum class ElementSubType { SCULPTURE, GAMEPLAY, AUDIO, CHARACTER_PUPPET, SHOWCASE_PAINTING, LOGIC_CHIP }

data class CreationMetadata(
    val id: String,
    var title: String,
    var description: String,
    var type: CreationType,
    var subType: ElementSubType? = null,
    var coverImageId: String? = null,
    var tags: MutableList<String> = mutableListOf(),
    var isRemixable: Boolean = true,
    var credits: MutableList<String> = mutableListOf(), // genealogy auto
    var genealogy: MutableList<String> = mutableListOf(), // ids of remixed creations
    var version: Int = 1,
    var isLocal: Boolean = true,
    var isPublished: Boolean = false,
    var contentWarnings: MutableList<String> = mutableListOf()
)

// My Creations screen
class MyCreationsManager {
    val creations = mutableMapOf<String, CreationMetadata>()
    fun saveAs(metadata: CreationMetadata) { creations[metadata.id] = metadata }
    fun getByType(type: CreationType) = creations.values.filter { it.type == type }
    fun getBySubType(sub: ElementSubType) = creations.values.filter { it.subType == sub }
    fun getLocal() = creations.values.filter { it.isLocal && !it.isPublished }
    fun getPublished() = creations.values.filter { it.isPublished }
    fun getGenealogy(id: String): List<String> = creations[id]?.genealogy ?: emptyList()
}

// DreamSurfing screen
data class DreamSurfingEntry(val dreamId: String, val title: String, val author: String, val tags: List<String>, val likes: Int, val isPrizeBubble: Boolean)
class DreamSurfingManager {
    val playlists = mapOf(
        "Mm Picks" to mutableListOf<DreamSurfingEntry>(),
        "New Trending" to mutableListOf<DreamSurfingEntry>(),
        "New For You" to mutableListOf<DreamSurfingEntry>(),
        "Community Jam" to mutableListOf<DreamSurfingEntry>()
    )
    var currentBanner: String = ""
    fun autosurf(): DreamSurfingEntry? = playlists.values.flatten().randomOrNull()
    fun search(query: String, tags: List<String>): List<DreamSurfingEntry> = playlists.values.flatten().filter { it.title.contains(query, true) || it.tags.any { t -> tags.contains(t) } }
    fun thumbsUp(dreamId: String) {}
    fun comment(dreamId: String, text: String) {}
    fun followCreator(author: String) {}
    fun followCreation(dreamId: String) {}
    fun suggestCollab(dreamId: String, msg: String) {}
}

// Homespace
class HomespaceManager {
    enum class HomespaceKit { WELCOME_HOME, ANCIENT_TEMPLE, NOIR, SCI_FI, FANTASY, BLANK }
    data class Homespace(val id: String, var kit: HomespaceKit, var decorations: MutableList<String> = mutableListOf(), var timeDecoratingMinutes: Int = 0)
    val homespaces = mutableMapOf<String, Homespace>()
    var dreamQueenHomespace = Homespace("dreamQueen", HomespaceKit.BLANK)
    fun createHomespace(id: String, kit: HomespaceKit) { homespaces[id] = Homespace(id, kit) }
    fun decorate(homespaceId: String, elementId: String) { homespaces[homespaceId]?.decorations?.add(elementId); homespaces[homespaceId]?.let { it.timeDecoratingMinutes++ } }
    fun getTimeDecorating(id: String) = homespaces[id]?.timeDecoratingMinutes ?: 0 // for Home Sweet Home trophy 30min
}

// Pre-fab puppets editable
class PuppetTemplateManager {
    enum class PuppetType { BASIC_PUPPET, DELUXE_PUPPET }
    data class PuppetTemplate(val type: PuppetType, val hasPuppetInterface: Boolean = true, val hasLegs: Boolean = true, val hasArms: Boolean = true, val tweakable: Map<String, Float> = mapOf("legHeight" to 1f, "legLength" to 1f, "walkSpeed" to 2f, "runSpeed" to 5f, "jumpHeight" to 2f))
    val templates = mapOf(
        PuppetType.BASIC_PUPPET to PuppetTemplate(PuppetType.BASIC_PUPPET, tweakable = mapOf("legHeight" to 1f)),
        PuppetType.DELUXE_PUPPET to PuppetTemplate(PuppetType.DELUXE_PUPPET, tweakable = mapOf("legHeight" to 1f, "legLength" to 1f, "armLength" to 1f, "walkSpeed" to 2f, "runSpeed" to 5f, "jumpHeight" to 2f, "doubleJump" to 0f, "canClimb" to 1f))
    )
    fun spawnPuppet(type: PuppetType, pos: Triple<Float,Float,Float>): String {
        val id = "puppet_${type.name}_${System.currentTimeMillis()}"
        // creates SceneObject with puppet interface + sculpt
        return id
    }
    fun editPuppetSculpt(puppetId: String, newSculptId: String) {}
    fun tweakPuppet(puppetId: String, param: String, value: Float) {}
}
