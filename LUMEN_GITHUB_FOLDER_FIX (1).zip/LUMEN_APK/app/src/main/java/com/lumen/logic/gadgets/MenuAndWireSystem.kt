package com.lumen.logic.ui

// --- MENU ANCHORING / RESIZING / MOVING / PINNING (Dreams does all 4) ---
enum class MenuAnchorMode { FOLLOW_OBJECT, PIN_TO_SCREEN, FREE_FLOAT, STICKER_HUD }

data class MenuInstance(
    val id: String,
    val targetGadgetId: String,
    var anchorMode: MenuAnchorMode = MenuAnchorMode.FOLLOW_OBJECT,
    var position: Triple<Float,Float,Float> = Triple(0f,0f,0f), // world pos when FOLLOW_OBJECT
    var screenAnchor: Pair<Float,Float> = Pair(0.5f, 0.5f), // 0-1 when PIN_TO_SCREEN or STICKER_HUD
    var size: Pair<Float,Float> = Pair(400f, 300f), // Dreams lets you resize tweak menus
    var scale: Float = 1f,
    var isPinned: Boolean = false, // pin to screen so it stays when you move
    var isCollapsed: Boolean = false,
    var opacity: Float = 0.95f,
    var alwaysOnTop: Boolean = false
)

class MenuManager {
    val menus = mutableMapOf<String, MenuInstance>()
    
    fun createMenu(gadgetId: String, mode: MenuAnchorMode = MenuAnchorMode.FOLLOW_OBJECT): MenuInstance {
        val m = MenuInstance("menu_$gadgetId", gadgetId, mode)
        menus[m.id] = m
        return m
    }
    
    // Dreams: you can grab top bar and move menu anywhere
    fun moveMenu(menuId: String, newWorldPos: Triple<Float,Float,Float>? = null, newScreenAnchor: Pair<Float,Float>? = null) {
        menus[menuId]?.let {
            newWorldPos?.let { p -> it.position = p; it.anchorMode = MenuAnchorMode.FREE_FLOAT }
            newScreenAnchor?.let { a -> it.screenAnchor = a; it.anchorMode = MenuAnchorMode.PIN_TO_SCREEN }
        }
    }
    
    // Dreams: drag corner to resize
    fun resizeMenu(menuId: String, newSize: Pair<Float,Float>, newScale: Float? = null) {
        menus[menuId]?.let { it.size = newSize; newScale?.let { s -> it.scale = s } }
    }
    
    // Dreams: pin button top-right — pins menu to screen so it follows camera
    fun pinMenu(menuId: String, pinned: Boolean) {
        menus[menuId]?.let {
            it.isPinned = pinned
            it.anchorMode = if(pinned) MenuAnchorMode.PIN_TO_SCREEN else MenuAnchorMode.FOLLOW_OBJECT
            it.alwaysOnTop = pinned
        }
    }
    
    // Dreams: double-tap top bar to collapse, or minimize
    fun collapseMenu(menuId: String, collapsed: Boolean) {
        menus[menuId]?.isCollapsed = collapsed
    }
    
    fun getMenusForGadget(gadgetId: String) = menus.values.filter { it.targetGadgetId == gadgetId }
    fun getPinnedMenus() = menus.values.filter { it.isPinned }
}

// --- WIRE PATH ROUTING — organize logic chips and wires (Dreams has full bezier routing) ---
enum class WireType { BEAM, DOTTED, FLEXIBLE } // Dreams: solid=power/data, dotted=signal pulse, flexible=physics

data class WireNode(
    val id: String,
    var pos: Triple<Float,Float,Float>,
    var isAnchor: Boolean = false // user-placed anchor to dictate path
)

data class WirePath(
    val wireId: String,
    var type: WireType = WireType.BEAM,
    var color: Triple<Float,Float,Float> = Triple(0f,1f,1f), // Dreams wire colors by signal type
    var thickness: Float = 2f,
    var nodes: MutableList<WireNode> = mutableListOf(), // user dictates path via nodes
    var isCurved: Boolean = true, // bezier vs straight
    var isOrganized: Boolean = false // auto-organize vs manual
)

class WireRouter {
    val paths = mutableMapOf<String, WirePath>()
    
    // Dreams: you can grab middle of wire and pull to create bend point
    fun addNodeToWire(wireId: String, pos: Triple<Float,Float,Float>): WireNode {
        val path = paths.getOrPut(wireId) { WirePath(wireId) }
        val node = WireNode("node_${wireId}_${path.nodes.size}", pos, isAnchor = true)
        path.nodes.add(node)
        return node
    }
    
    // Dreams: move node to reshape wire
    fun moveNode(wireId: String, nodeId: String, newPos: Triple<Float,Float,Float>) {
        paths[wireId]?.nodes?.find { it.id == nodeId }?.pos = newPos
    }
    
    // Dreams: you can set wire to go around chips, organize
    fun setWireType(wireId: String, type: WireType) {
        paths.getOrPut(wireId) { WirePath(wireId) }.type = type
    }
    
    fun setWireColor(wireId: String, color: Triple<Float,Float,Float>) {
        paths.getOrPut(wireId) { WirePath(wireId) }.color = color
    }
    
    // Dreams: auto-organize button tidies all wires
    fun autoOrganizeWires(chipId: String, engine: com.lumen.logic.core.LogicEngine) {
        val chipGadgets = engine.microchips[chipId] ?: return
        val chipWires = engine.wires.filter { it.fromGadget in chipGadgets && it.toGadget in chipGadgets }
        chipWires.forEach { wire ->
            val path = paths.getOrPut(wire.id) { WirePath(wire.id) }
            // Simple organized layout: stagger nodes to avoid overlap
            path.nodes.clear()
            path.isOrganized = true
            path.isCurved = true
            // Create 2 anchor points to route around
            path.nodes.add(WireNode("${wire.id}_mid1", Triple(0.5f,0f,0f), true))
            path.nodes.add(WireNode("${wire.id}_mid2", Triple(1f,0f,0f), true))
        }
    }
    
    // Dreams: you can hide/show wires per chip
    fun setWiresVisible(chipId: String, visible: Boolean, engine: com.lumen.logic.core.LogicEngine) {
        // stored in path metadata
    }
    
    // Get bezier points for rendering
    fun getWireRenderPoints(wireId: String, fromPos: Triple<Float,Float,Float>, toPos: Triple<Float,Float,Float>): List<Triple<Float,Float,Float>> {
        val path = paths[wireId] ?: return listOf(fromPos, toPos)
        if(path.nodes.isEmpty()) return listOf(fromPos, toPos)
        // Build bezier through anchors
        val points = mutableListOf<Triple<Float,Float,Float>>()
        points.add(fromPos)
        points.addAll(path.nodes.map { it.pos })
        points.add(toPos)
        return points
    }
}

// Combined: Full Dreams menu + wire organization system
class DreamsUIManager {
    val menuManager = MenuManager()
    val wireRouter = WireRouter()
    
    fun toFeatureMap(): Map<String, Boolean> = mapOf(
        "anchoring_followObject" to true,
        "anchoring_pinToScreen" to true,
        "anchoring_freeFloat" to true,
        "anchoring_stickerHUD" to true,
        "resizing_dragCorner" to true,
        "moving_grabTopBar" to true,
        "pinning_pinButton" to true,
        "collapsing_doubleTap" to true,
        "wire_beamType" to true,
        "wire_dottedType" to true,
        "wire_flexibleType" to true,
        "wire_nodes_anchorPoints" to true,
        "wire_curved_bezier" to true,
        "wire_colorByType" to true,
        "wire_autoOrganize" to true,
        "wire_hideShowPerChip" to true,
        "wire_thickness" to true
    )
}
