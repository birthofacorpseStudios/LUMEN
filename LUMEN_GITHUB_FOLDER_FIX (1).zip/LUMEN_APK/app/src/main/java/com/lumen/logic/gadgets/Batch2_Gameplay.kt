package com.lumen.logic.gadgets
import com.lumen.logic.core.*

class TextDisplayGadget(id: String): LogicGadget(id, "Text Display", "ic_text_display") {
    var text: String = "Hello LUMEN"
    var visible: Boolean = true
    init { input("show", SignalType.BOOL); input("setText", SignalType.OBJECT_REF); output("isVisible", SignalType.BOOL); output("textOut", SignalType.OBJECT_REF) }
    override fun onTick(d: Long, ctx: LogicContext) { emit("isVisible", visible, ctx); emit("textOut", text, ctx) }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext) { if(p=="show") visible = v as? Boolean ?: true; if(p=="setText") text = v as? String ?: text }
}

class SpeakerGadget(id: String): LogicGadget(id, "Speaker", "ic_speaker") {
    var audioClipId: String = ""; var volume: Float = 1f; var spatial: Boolean = true
    init { input("play", SignalType.PULSE); input("stop", SignalType.PULSE); input("volume", SignalType.FLOAT); output("isPlaying", SignalType.BOOL) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext) {
        when(p){ "play" -> { emit("isPlaying", true, ctx) /* hook to DAW unlimited disk stream */ }
                "stop" -> emit("isPlaying", false, ctx)
                "volume" -> volume = (v as? Float ?: 1f).coerceIn(0f,1f) }
    }
}

class CameraGadget(id: String): LogicGadget(id, "Camera", "ic_camera") {
    var fov: Float = 60f; var isActive: Boolean = false
    init { input("activate", SignalType.BOOL); input("follow", SignalType.OBJECT_REF); output("activeCam", SignalType.OBJECT_REF) }
    override fun onTick(d: Long, ctx: LogicContext) { if(isActive) emit("activeCam", id, ctx) }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){ if(p=="activate") isActive = v as? Boolean ?: false }
}

class CameraRigGadget(id: String): LogicGadget(id, "Camera Rig", "ic_camera_rig") {
    var railPoints: List<Triple<Float,Float,Float>> = emptyList(); var progress: Float = 0f
    init { input("progress", SignalType.FLOAT); input("activate", SignalType.BOOL); output("camPos", SignalType.VECTOR3) }
    override fun onTick(d: Long, ctx: LogicContext){ emit("camPos", railPoints.getOrNull((progress*railPoints.size).toInt()) ?: Triple(0f,0f,0f), ctx) }
}

class EmitterGadget(id: String): LogicGadget(id, "Emitter", "ic_emitter") {
    var prefabId: String = "cube"; var maxEmitted: Int = 20; var emitted: Int = 0
    init { input("emit", SignalType.PULSE); input("prefab", SignalType.OBJECT_REF); output("emittedObj", SignalType.OBJECT_REF); output("count", SignalType.FLOAT) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        if(p=="emit" && emitted < maxEmitted){
            val newId = "obj_${System.currentTimeMillis()}_$emitted"
            ctx.sceneObjects[newId] = SceneObject(newId, Triple(0f,0f,0f), Triple(0f,0f,0f))
            emitted++; emit("emittedObj", newId, ctx); emit("count", emitted.toFloat(), ctx)
        }
    }
}

class LaserScopeGadget(id: String): LogicGadget(id, "Laser Scope", "ic_laser_scope") {
    var range: Float = 10f
    init { input("scan", SignalType.PULSE); output("hit", SignalType.BOOL); output("hitObject", SignalType.OBJECT_REF); output("hitPos", SignalType.VECTOR3) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        if(p=="scan"){
            // simple raycast: find closest object with tag
            val hit = ctx.sceneObjects.values.firstOrNull()
            if(hit!=null){ emit("hit", true, ctx); emit("hitObject", hit.id, ctx); emit("hitPos", hit.pos, ctx) } else emit("hit", false, ctx)
        }
    }
}

class DoorwayGadget(id: String): LogicGadget(id, "Doorway", "ic_doorway") {
    var targetScene: String = "level2"
    init { input("enter", SignalType.PULSE); output("entered", SignalType.PULSE); output("scene", SignalType.OBJECT_REF) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){ if(p=="enter"){ emit("entered", true, ctx); emit("scene", targetScene, ctx) } }
}

class CheckpointGadget(id: String): LogicGadget(id, "Checkpoint", "ic_checkpoint") {
    var checkpointPos: Triple<Float,Float,Float> = Triple(0f,0f,0f)
    init { input("save", SignalType.PULSE); input("load", SignalType.PULSE); output("saved", SignalType.PULSE) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        if(p=="save"){ checkpointPos = ctx.sceneObjects.values.firstOrNull()?.pos ?: checkpointPos; emit("saved", true, ctx); ctx.variables["lastCheckpoint"]=checkpointPos }
        if(p=="load"){ val pos = ctx.variables["lastCheckpoint"] as? Triple<Float,Float,Float> ?: checkpointPos; ctx.sceneObjects.values.forEach{ it.pos=pos } }
    }
}

class SunSkyFogGadget(id: String): LogicGadget(id, "Sun Sky Fog", "ic_sun_sky_fog") {
    var sunAngle: Float = 45f; var fogDensity: Float = 0.1f
    init { input("sunAngle", SignalType.FLOAT); input("fog", SignalType.FLOAT); output("skyColor", SignalType.VECTOR3) }
    override fun onTick(d: Long, ctx: LogicContext){ emit("skyColor", Triple(sunAngle/90f, 0.5f, 1f-fogDensity), ctx) }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){ if(p=="sunAngle") sunAngle=v as? Float ?: sunAngle; if(p=="fog") fogDensity=v as? Float ?: fogDensity }
}
