package com.lumen.offline

// OFFLINE-ONLY STORAGE — removes all online features
class LocalStorageManager {
    val localPath = "/data/data/com.lumen.app/files/creations/"
    enum class StorageLocation { INTERNAL, SD_CARD, APP_PRIVATE }
    fun saveLocal(creationId: String, data: ByteArray, location: StorageLocation = StorageLocation.APP_PRIVATE) {}
    fun loadLocal(creationId: String): ByteArray? { return null }
    fun deleteLocal(creationId: String) {}
    fun listLocal(): List<String> { return emptyList() }
    fun getLocalCreations() = listLocal()
}

enum class ExportFormat {
    APK, EXE, HTML, JAVA,
    MP3, MIDI, WAV, OGG, FLAC,
    OBJ, FBX, GLTF, GLB, STL, BLEND, DAE, PLY
}

data class ExportJob(val creationId: String, val creationType: String, val format: ExportFormat, val outputPath: String, var progress: Float = 0f)

class ExportManager {
    fun getAvailableFormats(creationType: String): List<ExportFormat> {
        return when(creationType) {
            "DREAM", "SCENE", "GAMEPLAY" -> listOf(ExportFormat.APK, ExportFormat.EXE, ExportFormat.HTML, ExportFormat.JAVA)
            "AUDIO", "MUSIC" -> listOf(ExportFormat.MP3, ExportFormat.MIDI, ExportFormat.WAV, ExportFormat.OGG, ExportFormat.FLAC)
            "SCULPTURE", "CHARACTER_PUPPET", "ELEMENT" -> listOf(ExportFormat.OBJ, ExportFormat.FBX, ExportFormat.GLTF, ExportFormat.GLB, ExportFormat.STL, ExportFormat.BLEND, ExportFormat.DAE, ExportFormat.PLY)
            else -> ExportFormat.values().toList()
        }
    }
    fun export(creationId: String, format: ExportFormat, outputPath: String): ExportJob {
        return ExportJob(creationId, "UNKNOWN", format, outputPath)
    }
}

class ScreenRecordManager {
    enum class ShareAction { SINGLE_PRESS_SCREENSHOT, DOUBLE_PRESS_RECORD_START_STOP, LONG_PRESS_SAVE_CLIP }
    var isRecording: Boolean = false
    var currentRecordingPath: String? = null
    fun onShareButton(action: ShareAction) {
        when(action) {
            ShareAction.SINGLE_PRESS_SCREENSHOT -> takeScreenshot()
            ShareAction.DOUBLE_PRESS_RECORD_START_STOP -> { if(isRecording) stopRecording() else startRecording() }
            ShareAction.LONG_PRESS_SAVE_CLIP -> saveLastClip()
        }
    }
    fun takeScreenshot() {}
    fun startRecording() { isRecording = true; currentRecordingPath = "/DCIM/LUMEN/record_${System.currentTimeMillis()}.mp4" }
    fun stopRecording() { isRecording = false }
    fun saveLastClip() {}
    fun bindToController(ps4SharePressed: Boolean, pressType: ShareAction) { if(ps4SharePressed) onShareButton(pressType) }
}

class RemixManager {
    data class RemixOptions(var allowRemix: Boolean = true, var isRemix: Boolean = false, var originalId: String? = null, var genealogy: MutableList<String> = mutableListOf(), var keepOriginal: Boolean = true, var remixType: String = "COPY_EDIT")
    fun createRemix(originalId: String, newTitle: String): String {
        return "remix_${originalId}_${System.currentTimeMillis()}"
    }
    fun getRemixHistory(creationId: String): List<String> { return emptyList() }
    fun isRemixable(creationId: String): Boolean { return true }
}

class OfflineLumenSystem {
    val storage = LocalStorageManager()
    val export = ExportManager()
    val screenRecord = ScreenRecordManager()
    val remix = RemixManager()
    fun isOnline(): Boolean = false
}
