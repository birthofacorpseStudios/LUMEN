package com.lumen.offline

// V6 — Stripped per user: remove all DreamSurfing social, homespaces, trophies, collab
class StrippedSystem {
    // REMOVED per request:
    val removed = listOf(
        "DreamSurfing Mm Picks",
        "DreamSurfing Trending",
        "DreamSurfing Autosurf",
        "DreamSurfing tags search online",
        "thumbs up",
        "comment",
        "follow creator",
        "follow creation",
        "collab / collaboration suggest",
        "Prize Bubbles",
        "homespaces (personal hub)",
        "Dream Queen's homespace tutorial",
        "Home Sweet Home trophy 30min decorating",
        "allowRemix toggle",
        "COLLABORATION remixType",
        "Welcome Home / Ancient Temple kits as online kits",
        "Community Jam",
        "Mm Picks / Trending banners"
    )
    
    // KEPT — pure creation mode only
    val kept = listOf(
        "My Creations local only",
        "Scene Editor same as Dreams",
        "Search YOUR OWN creations for elements to stamp into scene",
        "Search puppets (your own puppet templates) to stamp",
        "Sculpt/Paint/Assembly/Animation/Sound modes",
        "Save as Element/Scene/Dream/Collection with subtypes",
        "Local offline storage only",
        "Export to APK/EXE/HTML/JAVA/MP3/MIDI/WAV/OBJ/FBX/etc",
        "Screen record via Share button",
        "Local remixing COPY_EDIT / REFERENCE only (no COLLABORATION)"
    )
}

// Creation Mode Search — search own creations to stamp into scene
class CreationSearchManager {
    // Dreams Assembly Mode search: search Dreamiverse for Elements to stamp
    // LUMEN V6: search YOUR OWN local creations only (no online)
    data class SearchResult(val id: String, val title: String, val type: String, val subType: String, val thumbnail: String?)
    
    val localCreations = mutableMapOf<String, SearchResult>()
    
    fun searchOwnCreations(query: String, filterType: String? = null): List<SearchResult> {
        // query = "lamp", "puppet", "basic puppet" etc
        // filters: SCULPTURE, GAMEPLAY, AUDIO, CHARACTER_PUPPET, SHOWCASE, etc
        return localCreations.values.filter {
            (query.isEmpty() || it.title.contains(query, ignoreCase = true)) &&
            (filterType == null || it.subType == filterType || it.type == filterType)
        }
    }
    
    fun searchPuppets(query: String = ""): List<SearchResult> {
        return searchOwnCreations(query, "CHARACTER_PUPPET")
    }
    
    fun stampIntoScene(elementId: String, sceneId: String, position: Triple<Float,Float,Float>) {
        // Drops element from your library into current scene at position
        // Like Dreams: type "lamp" in search, select, drop into Scene
        // Supports editing after stamp: repaint, retweak, etc
    }
}

// Scene Editor — works same as Dreams Edit Mode
class SceneEditorManager {
    // Dreams Edit Mode has: Assembly, Sculpt, Paint, Animation, Sound, Test
    enum class EditMode { ASSEMBLY, SCULPT, PAINT, ANIMATION, SOUND, TEST }
    
    var currentMode: EditMode = EditMode.ASSEMBLY
    var currentSceneId: String? = null
    
    // Assembly Mode = where you search and stamp Elements + place gadgets
    fun enterAssemblyMode() { currentMode = EditMode.ASSEMBLY }
    // Sculpt Mode = create objects with primitives, flecks, looseness, wax etc
    fun enterSculptMode() { currentMode = EditMode.SCULPT }
    // Paint Mode = fleck paint, splat, coat, gradient
    fun enterPaintMode() { currentMode = EditMode.PAINT }
    // Animation Mode = timeline, keyframes, action recorder
    fun enterAnimationMode() { currentMode = EditMode.ANIMATION }
    // Sound Mode = DAW, 16 pads, unlimited recording
    fun enterSoundMode() { currentMode = EditMode.SOUND }
    // Test Mode = play scene with live gadget debug
    fun enterTestMode() { currentMode = EditMode.TEST }
    
    // Same as Dreams: you can scope into object and edit, clone with L1+R2, R1 hold camera relative, L1+Circle exit editor
    fun scopeIntoObject(objectId: String) {}
    fun cloneObject(objectId: String) {} // L1+R2
    fun exitEditor() {} // L1+Circle
    
    // Works same: all items made of flecks, looseness, impasto, soft blend etc
    fun getCurrentModeFeatures(): List<String> {
        return when(currentMode) {
            EditMode.ASSEMBLY -> listOf("search own creations", "stamp elements", "place gadgets", "wire gadgets", "microchips", "group/ungroup")
            EditMode.SCULPT -> listOf("sphere/cube/cylinder/lozenge", "looseness", "wax", "metallic", "glow", "fleck type/density", "opacity", "cutout", "soft blend", "impasto", "bevel", "smear", "stamp", "spray", "clone", "grid", "mirror", "guides")
            EditMode.PAINT -> listOf("fleck/splat/coat/gradient", "15 fleck shapes", "mirror", "kaleidoscope")
            EditMode.ANIMATION -> listOf("timeline", "keyframes", "labels", "playhead", "looping", "ping-pong", "onion skin", "blend", "action recorder", "performance recorder")
            EditMode.SOUND -> listOf("16 pads", "infinite disk-streamed recording", "piano roll", "step sequencer", "drum kits", "FX rack reverb/delay/EQ/compressor/chorus", "instrument SAW/SQR/SIN/TRI/NOISE + sampler")
            EditMode.TEST -> listOf("play with live gadget debug", "see gadgets windows live", "thermo display")
        }
    }
}

// Updated Remix — no allowRemix toggle, no COLLABORATION
class RemixManagerV6 {
    data class RemixOptions(var isRemix: Boolean = false, var originalId: String? = null, var genealogy: MutableList<String> = mutableListOf(), var keepOriginal: Boolean = true, var remixType: String = "COPY_EDIT") // only COPY_EDIT / REFERENCE
    fun createRemix(originalId: String, newTitle: String): String {
        return "remix_${originalId}_${System.currentTimeMillis()}"
    }
    fun getRemixHistory(creationId: String): List<String> { return emptyList() }
}
