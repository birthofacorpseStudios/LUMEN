package com.lumen.settings

// Dreams has full controller options, hint toggle, UI customization — we must not miss
class ControllerOptionsManager {
    // Dreams Control Schemes (from gamertweak guide)
    enum class ControlScheme { DEFAULT_MOTION_PLUS_STICKS, STICKS_ONLY, MOVE_CONTROLLERS }
    
    data class ControllerSettings(
        var scheme: ControlScheme = ControlScheme.DEFAULT_MOTION_PLUS_STICKS,
        var motionControlsEnabled: Boolean = true,
        var leftStickSensitivity: Float = 1f,
        var rightStickSensitivity: Float = 1f,
        var motionSensitivity: Float = 1f,
        var invertY: Boolean = false,
        var invertX: Boolean = false,
        var vibrationEnabled: Boolean = true,
        var wispSpeed: Float = 1f, // imp/wisp speed
        var wispSize: Float = 1f,
        var l1R2CloneEnabled: Boolean = true,
        var r1CameraRelative: Boolean = true,
        var l1CircleExit: Boolean = true,
        var touchpadMenuEnabled: Boolean = true,
        var optionsHoldRecenter: Boolean = true,
        var shareButtonScreenshot: Boolean = true,
        var shareButtonDoubleRecord: Boolean = true,
        var shareButtonLongClip: Boolean = true,
        var ps4ButtonMapping: Map<String, String> = mapOf(
            "cross" to "jump/select",
            "circle" to "exit/back",
            "square" to "grab/action",
            "triangle" to "tweak menu L1+Triangle",
            "L1" to "modifier",
            "R1" to "camera focus",
            "L2" to "grab left",
            "R2" to "grab right",
            "L3" to "scope",
            "R3" to "reset camera",
            "touchpad" to "full-screen floating menu",
            "options" to "hold to recenter wisp"
        )
    )
    
    var settings = ControllerSettings()
    
    fun setScheme(scheme: ControlScheme) { settings.scheme = scheme }
    fun setSensitivity(left: Float? = null, right: Float? = null, motion: Float? = null) {
        left?.let { settings.leftStickSensitivity = it }
        right?.let { settings.rightStickSensitivity = it }
        motion?.let { settings.motionSensitivity = it }
    }
}

class HintSystemManager {
    // Dreams has hint toggle + tutorials
    var hintsEnabled: Boolean = true
    var tutorialHintsEnabled: Boolean = true
    var gadgetTooltipsEnabled: Boolean = true
    var moreInfoTooltipEnabled: Boolean = true // tiny wee example for each gadget
    var contextSensitiveHints: Boolean = true
    
    fun toggleHints(enabled: Boolean) {
        hintsEnabled = enabled
        tutorialHintsEnabled = enabled
        gadgetTooltipsEnabled = enabled
        moreInfoTooltipEnabled = enabled
    }
    
    fun showHint(gadgetId: String): String {
        // returns tooltip text for gadget
        return "Hint for $gadgetId"
    }
}

class UICustomizationManager {
    // Dreams UI customization options
    data class UISettings(
        var theme: String = "default_dark", // dark theme like Dreams
        var menuScale: Float = 1f,
        var menuOpacity: Float = 0.95f,
        var wispCustomization: String = "default", // imp/wisp customizable
        var wispColor: Triple<Float,Float,Float> = Triple(1f,1f,1f),
        var showThermo: Boolean = true,
        var showGadgetPorts: Boolean = true,
        var showWireColors: Boolean = true,
        var wireThickness: Float = 2f,
        var showGrid: Boolean = true,
        var gridSize: Float = 1f,
        var showGuides: Boolean = true,
        var showOnionSkin: Boolean = true,
        var showKeyframes: Boolean = true,
        var showTimelineLabels: Boolean = true,
        var menuAnchorDefault: String = "FOLLOW_OBJECT", // FOLLOW_OBJECT, PIN_TO_SCREEN, FREE_FLOAT, STICKER_HUD
        var autoHideUI: Boolean = false,
        var showFPS: Boolean = false,
        var language: String = "en",
        var showControllerHints: Boolean = true,
        var threeDotsMenuTopRight: Boolean = true // Dreams has 3 dots menu top right for control scheme, sensitivity etc
    )
    
    var ui = UISettings()
    
    fun customizeMenu(scale: Float? = null, opacity: Float? = null, anchor: String? = null) {
        scale?.let { ui.menuScale = it }
        opacity?.let { ui.menuOpacity = it }
        anchor?.let { ui.menuAnchorDefault = it }
    }
    
    fun customizeWisp(color: Triple<Float,Float,Float>? = null, size: Float? = null) {
        color?.let { ui.wispColor = it }
    }
    
    fun toggleThermo(show: Boolean) { ui.showThermo = show }
    fun toggleGrid(show: Boolean, size: Float? = null) { ui.showGrid = show; size?.let { ui.gridSize = it } }
}

class CompleteSettingsSystem {
    val controller = ControllerOptionsManager()
    val hints = HintSystemManager()
    val ui = UICustomizationManager()
    
    fun getAllOptions(): Map<String, Any> = mapOf(
        "controller_schemes" to ControllerOptionsManager.ControlScheme.values().map { it.name },
        "controller_sensitivity" to listOf("leftStickSensitivity", "rightStickSensitivity", "motionSensitivity", "wispSpeed", "wispSize"),
        "controller_toggles" to listOf("motionControlsEnabled", "invertX", "invertY", "vibrationEnabled", "touchpadMenu", "optionsHoldRecenter", "shareButton"),
        "controller_mapping" to controller.settings.ps4ButtonMapping,
        "hint_toggle" to listOf("hintsEnabled", "tutorialHintsEnabled", "gadgetTooltipsEnabled", "moreInfoTooltipEnabled", "contextSensitiveHints"),
        "ui_customization" to listOf("theme", "menuScale", "menuOpacity", "wispColor", "wispCustomization", "showThermo", "showGadgetPorts", "showWireColors", "wireThickness", "showGrid", "gridSize", "showGuides", "showOnionSkin", "showKeyframes", "showTimelineLabels", "menuAnchorDefault", "autoHideUI", "showFPS", "language", "threeDotsMenuTopRight")
    )
}
