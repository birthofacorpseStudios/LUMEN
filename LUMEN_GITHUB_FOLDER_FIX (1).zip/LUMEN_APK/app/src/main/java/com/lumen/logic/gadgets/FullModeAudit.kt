package com.lumen.logic.gadgets
import com.lumen.logic.core.*

// Speaker: Dreams has 3D spatial vs 2D stereo + cone modes
class SpeakerGadgetFull(id: String): LogicGadget(id, "Speaker", "ic_speaker") {
    enum class Mode { SPATIAL_3D, STEREO_2D, CONE }
    var mode: Mode = Mode.SPATIAL_3D
    var volume=1f; var range=10f; var coneAngle=90f; var coneFalloff=0.5f
    var audioClipId=""; var isPlaying=false
    init {
        input("play", SignalType.PULSE); input("stop", SignalType.PULSE); input("volume", SignalType.FLOAT)
        input("range", SignalType.FLOAT); input("mode", SignalType.FLOAT)
        input("position", SignalType.VECTOR3) // in-scene
        output("isPlaying", SignalType.BOOL); output("volumeOut", SignalType.FLOAT)
    }
    override fun onTick(d: Long, ctx: LogicContext) { emit("isPlaying", isPlaying, ctx); emit("volumeOut", volume, ctx) }
    override fun onSignal(p: String, v: Any?, ctx: LogicContext) {
        when(p){ "play"-> isPlaying=true; "stop"-> isPlaying=false; "volume"-> volume=(v as? Float ?:1f).coerceIn(0f,1f)
                "range"-> range=v as? Float ?: range; "mode"-> mode=Mode.values()[((v as? Float ?:0f).toInt()).coerceIn(0,2)] }
    }
    fun toTweak(): Map<String, Any> = mapOf("mode" to mode.name, "volume" to volume, "range" to range, "coneAngle" to coneAngle, "coneFalloff" to coneFalloff)
}

// Emitter: Dreams has world vs local space + emit at vs emit from
class EmitterGadgetFull(id: String): LogicGadget(id, "Emitter", "ic_emitter") {
    enum class Space { WORLD, LOCAL }
    enum class EmitMode { AT_EMITTER, FROM_PREVIOUS }
    var space: Space = Space.WORLD; var emitMode: EmitMode = EmitMode.AT_EMITTER
    var prefabId="cube"; var maxEmitted=20; var emitted=0; var lifespan=10f; var velocity=Triple(0f,0f,0f)
    var inheritVelocity=false; var hiddenAtEmit=false; var scaleAtEmit=1f; var emitRate=1f
    init {
        input("emit", SignalType.PULSE); input("prefab", SignalType.OBJECT_REF); input("velocity", SignalType.VECTOR3)
        input("spaceMode", SignalType.FLOAT); input("emitMode", SignalType.FLOAT)
        output("emittedObj", SignalType.OBJECT_REF); output("count", SignalType.FLOAT)
    }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        if(p=="emit" && emitted<maxEmitted){
            val newId="obj_${System.currentTimeMillis()}_$emitted"
            val pos = if(space==Space.WORLD) Triple(0f,0f,0f) else ctx.sceneObjects.values.firstOrNull()?.pos ?: Triple(0f,0f,0f)
            ctx.sceneObjects[newId]=SceneObject(newId, pos, Triple(0f,0f,0f), scaleAtEmit)
            emitted++; emit("emittedObj", newId, ctx); emit("count", emitted.toFloat(), ctx)
        }
        if(p=="spaceMode") space = if((v as? Float ?:0f)<0.5f) Space.WORLD else Space.LOCAL
        if(p=="emitMode") emitMode = if((v as? Float ?:0f)<0.5f) EmitMode.AT_EMITTER else EmitMode.FROM_PREVIOUS
    }
}

// Laser Scope: Dreams has raycast modes — scene vs object, surface vs center
class LaserScopeGadgetFull(id: String): LogicGadget(id, "Laser Scope", "ic_laser_scope") {
    enum class Mode { SCENE, OBJECT, TAG }
    enum class HitType { SURFACE, CENTER }
    var mode: Mode = Mode.SCENE; var hitType: HitType = HitType.SURFACE
    var range=10f; var includeSelf=false; var filterTag=""
    init {
        input("scan", SignalType.PULSE); input("range", SignalType.FLOAT); input("mode", SignalType.FLOAT)
        input("filterTag", SignalType.OBJECT_REF); input("position", SignalType.VECTOR3); input("direction", SignalType.VECTOR3)
        output("hit", SignalType.BOOL); output("hitObject", SignalType.OBJECT_REF); output("hitPos", SignalType.VECTOR3); output("hitNormal", SignalType.VECTOR3)
    }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext){
        when(p){
            "scan"-> {
                val hit = if(mode==Mode.TAG) ctx.sceneObjects.values.firstOrNull{ it.tags.contains(filterTag) } else ctx.sceneObjects.values.firstOrNull()
                if(hit!=null){ emit("hit", true, ctx); emit("hitObject", hit.id, ctx); emit("hitPos", hit.pos, ctx); emit("hitNormal", Triple(0f,1f,0f), ctx) } else emit("hit", false, ctx)
            }
            "range"-> range=v as? Float ?: range
            "mode"-> mode=Mode.values()[((v as? Float ?:0f).toInt()).coerceIn(0,2)]
            "filterTag"-> filterTag=v as? String ?: filterTag
        }
    }
}
