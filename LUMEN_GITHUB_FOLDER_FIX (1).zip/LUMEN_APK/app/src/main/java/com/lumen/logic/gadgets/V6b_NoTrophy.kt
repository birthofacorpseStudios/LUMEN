package com.lumen.offline

class NoTrophySystem {
    val removedTrophies = listOf(
        "Home Sweet Home - Spend 30 minutes decorating your homespace",
        "Just Dropping In - Revisit Dream Queen's homespace",
        "Complete 5 tutorials",
        "All trophy list from Dreams PS4 Trophy List Revealed",
        "Any trophy/achievement system"
    )
    fun hasTrophySystem(): Boolean = false
}
