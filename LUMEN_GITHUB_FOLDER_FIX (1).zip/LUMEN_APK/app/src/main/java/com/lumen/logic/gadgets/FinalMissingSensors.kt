package com.lumen.logic.gadgets
import com.lumen.logic.core.*

class TimeDateGadget(id: String): LogicGadget(id, "Time & Date", "ic_time_date") {
    // NEW v2.44 Dreams gadget
    init { output("year", SignalType.FLOAT); output("month", SignalType.FLOAT); output("day", SignalType.FLOAT); output("hour", SignalType.FLOAT); output("minute", SignalType.FLOAT); output("second", SignalType.FLOAT) }
    override fun onTick(d: Long, ctx: LogicContext) {
        val now = java.util.Calendar.getInstance()
        emit("year", now.get(java.util.Calendar.YEAR).toFloat(), ctx)
        emit("month", (now.get(java.util.Calendar.MONTH)+1).toFloat(), ctx)
        emit("day", now.get(java.util.Calendar.DAY_OF_MONTH).toFloat(), ctx)
        emit("hour", now.get(java.util.Calendar.HOUR_OF_DAY).toFloat(), ctx)
        emit("minute", now.get(java.util.Calendar.MINUTE).toFloat(), ctx)
        emit("second", now.get(java.util.Calendar.SECOND).toFloat(), ctx)
    }
}

class ImpactSensorGadget(id: String, val target: String): LogicGadget(id, "Impact Sensor", "ic_impact_sensor") {
    var threshold=1f
    init { input("threshold", SignalType.FLOAT); output("impact", SignalType.PULSE); output("force", SignalType.FLOAT) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    override fun onSignal(p: String, v: Any?, ctx: LogicContext) {
        // triggered by collision system
        emit("impact", true, ctx); emit("force", threshold, ctx)
    }
}

class TouchSensorGadget(id: String, val target: String): LogicGadget(id, "Touch Sensor", "ic_touch_sensor") {
    init { output("touched", SignalType.BOOL); output("toucher", SignalType.OBJECT_REF) }
    override fun onTick(d: Long, ctx: LogicContext) {}
    fun onTouch(toucherId: String, ctx: LogicContext){ emit("touched", true, ctx); emit("toucher", toucherId, ctx) }
}

class MathGadgets(id: String): LogicGadget(id, "Math Pack", "ic_math") {
    // Covers 4x Array, RGB Selector, 1D/5D/9D Blend Space, Time Derivative/Integral
    init {
        input("a", SignalType.FLOAT); input("b", SignalType.FLOAT); input("c", SignalType.FLOAT); input("d", SignalType.FLOAT)
        output("sum", SignalType.FLOAT); output("rgb", SignalType.VECTOR3); output("blend1D", SignalType.FLOAT); output("derivative", SignalType.FLOAT)
    }
    override fun onTick(d: Long, ctx: LogicContext) {
        val a = inputs["a"]?.value as? Float ?:0f; val b = inputs["b"]?.value as? Float ?:0f
        emit("sum", a+b, ctx); emit("rgb", Triple(a,b, inputs["c"]?.value as? Float ?:0f), ctx)
        emit("blend1D", a*0.5f+b*0.5f, ctx); emit("derivative", (b-a)/(d/1000f), ctx)
    }
}
