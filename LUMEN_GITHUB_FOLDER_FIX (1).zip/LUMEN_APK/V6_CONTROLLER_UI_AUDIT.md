# Controller Options, Hint Toggle, UI Customization — Dreams vs LUMEN V6c

## Dreams Controller Options (from gamertweak guide + docs):
- Control Schemes: DEFAULT_MOTION_PLUS_STICKS, STICKS_ONLY, MOVE_CONTROLLERS — changeable via 3 dots menu top right
- Motion Controls toggle on/off
- Left/Right stick sensitivity sliders
- Motion sensitivity slider
- Invert X/Y toggles
- Vibration toggle
- Wisp/Imp speed and size
- L1+R2 clone, R1 hold camera relative, L1+Circle exit editor — all togglable
- PS4 mapping: cross=jump/select, circle=exit/back, square=grab/action, triangle=tweak menu (L1+Triangle), L1=modifier, R1=camera focus, L2/R2=grab, L3=scope, R3=reset camera, Touchpad=full-screen floating menu, Options=hold to recenter wisp, Share=screen capture/record
- Touchpad menu enabled toggle, Options hold recenter toggle
- Share button: single=screenshot, double=record, long=save clip

## Dreams Hint Toggle:
- Hints enabled toggle
- Tutorial hints
- Gadget tooltips (hover over gadget shows tooltip)
- More info tooltip (tiny wee example for each gadget with scene floor)
- Context sensitive hints

## Dreams UI Customization:
- Theme (default dark like Dreams)
- Menu scale, opacity
- Wisp/Imp customization (customizable imp, color)
- Show thermo (gameplay/graphics/audio/logic meters)
- Show gadget ports, show wire colors, wire thickness
- Grid toggle + grid size, guides toggle
- Onion skin toggle, keyframes toggle, timeline labels toggle
- Menu anchor default (FOLLOW_OBJECT/PIN_TO_SCREEN/FREE_FLOAT/STICKER_HUD)
- Auto-hide UI, Show FPS, Language
- 3 dots menu top right corner for control scheme, sensitivity etc
- Show controller hints

## LUMEN V6c NOW HAS ALL:
- ControllerOptionsManager with scheme, sensitivities, invert, vibration, wisp speed/size, all button mappings, touchpad/options/share toggles
- HintSystemManager with hintsEnabled, tutorialHints, gadgetTooltips, moreInfoTooltip, contextSensitive, toggleHints()
- UICustomizationManager with theme, menuScale/Opacity, wispColor/Customization, showThermo/Ports/WireColors/Grid/Guides/Onion/Keyframes/Labels, menuAnchorDefault, autoHideUI, showFPS, language, threeDotsMenuTopRight

All accessible via floating full-screen settings menu + PS4 Options + 3 dots menu top right (same as Dreams).

**Verdict: Controller options, hint toggle, UI customization all now implemented, zero missing.**
